/** Transformação exclusiva do servidor de teste. Não é importada pelo jogo. */
export function lightingScrollExperiment(source) {
  const match = source.match(/if \((!invalidada &&[\s\S]*?)\) return;/);
  if (!match) throw new Error("Guarda de invalidação não encontrada");
  const stable = match[1].replace("ultimoQuadro.e === m.e && ultimoQuadro.f === m.f &&", "");
  let result = source.replace("let encerrada = false;", `
    const scrollCanvas = document.createElement("canvas");
    const scrollContext = scrollCanvas.getContext("2d");
    const scrollStats = scene.__scrollStats = { compositions: 0, stable: 0, fractional: 0, used: 0 };
    let encerrada = false;`);
  result = result.replace("    invalidada = false;", `
    scrollStats.compositions++;
    const scrollStable = ${stable};
    const scrollDx = (m.e - ultimoQuadro.e) * larguraMascara / width;
    const scrollDy = (m.f - ultimoQuadro.f) * alturaMascara / height;
    const scrollInteger = Number.isInteger(scrollDx) && Number.isInteger(scrollDy);
    if (scrollStable) { scrollStats.stable++; if (!scrollInteger) scrollStats.fractional++; }
    const scrollUse = !!scene.__scrollEnabled && scrollStable && scrollInteger &&
      Math.abs(scrollDx) < larguraMascara && Math.abs(scrollDy) < alturaMascara;
    invalidada = false;`);
  const marker = "    transformarMascara(context);\n    context.globalAlpha = 1;";
  result = result.replace(marker, `
    if (scrollUse) {
      scrollStats.used++;
      if (scrollCanvas.width !== larguraMascara || scrollCanvas.height !== alturaMascara) {
        scrollCanvas.width = larguraMascara; scrollCanvas.height = alturaMascara;
      }
      scrollContext.globalCompositeOperation = "copy";
      scrollContext.drawImage(texture.getSourceImage(), 0, 0);
      context.save(); context.setTransform(1, 0, 0, 1, 0, 0);
      context.globalAlpha = 1; context.globalCompositeOperation = "copy";
      context.drawImage(scrollCanvas, scrollDx, scrollDy);
      context.beginPath();
      if (scrollDx > 0) context.rect(0, 0, scrollDx, alturaMascara);
      if (scrollDx < 0) context.rect(larguraMascara + scrollDx, 0, -scrollDx, alturaMascara);
      if (scrollDy > 0) context.rect(0, 0, larguraMascara, scrollDy);
      if (scrollDy < 0) context.rect(0, alturaMascara + scrollDy, larguraMascara, -scrollDy);
      context.clip();
    }
${marker}`);
  result = result.replace('    context.globalCompositeOperation = "source-over";\n    texture.refresh();',
    '    context.globalCompositeOperation = "source-over";\n    if (scrollUse) context.restore();\n    texture.refresh();');
  result = result.replace("    encerrada = true;", `    encerrada = true;
    scrollCanvas.width = scrollCanvas.height = 0;
    if (scene.__scrollStats === scrollStats) delete scene.__scrollStats;`);
  if (result === source || !result.includes("if (scrollUse) context.restore()")) throw new Error("Transformação incompleta");
  return result;
}
