/** Cache de uma região 512×512 por instância; somente para ensaio no navegador. */
export function fixedWorldPatchExperiment(Class) {
  const original = Class.prototype.desenhar, destroy = Class.prototype.destroy;
  const entries = new WeakMap(), live = new Set();
  let enabled = false;
  const stats = { hits:0, builds:0, fallbacks:0, bytes:0 };
  const release = entry => {
    for (const canvas of entry.canvases) canvas.width = canvas.height = 0;
    live.delete(entry); stats.bytes -= 2 * 512 * 512 * 4;
  };
  Class.prototype.desenhar = function(context, color, camera) {
    if (!enabled) return original.call(this,context,color,camera);
    if (this.areaSuja) this.atualizarArea();
    const view = camera.worldView, x = Math.floor((view.x+view.width/2)/512)*512;
    const y = Math.floor((view.y+view.height/2)/512)*512;
    if (!this.individual || !view || view.x<x+2 || view.y<y+2 ||
        view.right>x+510 || view.bottom>y+510 || camera.rotation) {
      stats.firstFallback ??= { individual:this.individual, area:this.area,
        view:{x:view?.x,y:view?.y,width:view?.width,height:view?.height,right:view?.right,bottom:view?.bottom},x,y };
      stats.fallbacks++; return original.call(this,context,color,camera);
    }
    let entry=entries.get(this);
    if (!entry) {
      entry={canvases:[document.createElement("canvas"),document.createElement("canvas")]};
      for(const canvas of entry.canvases)canvas.width=canvas.height=512;
      entries.set(this,entry);live.add(entry);stats.bytes+=2*512*512*4;
    }
    if(entry.x!==x||entry.y!==y||entry.revision!==this.revisao){
      entry.x=x;entry.y=y;entry.revision=this.revisao;stats.builds++;
      for(let i=0;i<2;i++){
        const c=entry.canvases[i].getContext("2d");c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,512,512);
        c.setTransform(1,0,0,1,-x,-y);c.globalCompositeOperation="source-over";
        this.pintarFontes(c,!!i,null,{left:x,top:y,right:x+512,bottom:y+512});
      }
    }else stats.hits++;
    context.save();context.globalAlpha=1;context.drawImage(entry.canvases[Number(!!color)],x,y);context.restore();
  };
  Class.prototype.destroy = function(...args){
    const entry=entries.get(this);if(entry){release(entry);entries.delete(this);}
    return destroy.apply(this,args);
  };
  return {stats,enable(value){enabled=value;},restore(){
    Class.prototype.desenhar=original;Class.prototype.destroy=destroy;
    for(const entry of [...live])release(entry);
  }};
}
