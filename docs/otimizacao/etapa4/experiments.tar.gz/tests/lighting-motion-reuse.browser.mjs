/** Experimento isolado de translação exata e recomposição das faixas expostas. */
import assert from "node:assert/strict";
import { writeFileSync } from "node:fs";
import { abrirSessaoNovoBoss } from "./novo-boss-browser-helpers.mjs";
import { novoBossConfig } from "../js/enemies/novoBoss/NovoBossConfig.js";
if (process.env.LIGHTING_SCROLL_EXPERIMENT !== "1") throw new Error("Use LIGHTING_SCROLL_EXPERIMENT=1");
const session = await abrirSessaoNovoBoss(novoBossConfig, { spawnX:-1100, spawnY:-4800 }, {
  viewport:{width:960,height:540},hasTouch:true,isMobile:true,
  userAgent:"Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
}, { waitForBoss:false });
try {
  const cdp=await session.context.newCDPSession(session.page);
  await cdp.send("Emulation.setCPUThrottlingRate",{rate:4});
  const reports=[];
  for (const portrait of [false,true]) {
    if(portrait) {
      await session.page.evaluate(async()=>{if(document.fullscreenElement)await document.exitFullscreen();});
      await session.page.setViewportSize({width:390,height:844});
      await session.page.waitForTimeout(500);
    }
    const report=await session.page.evaluate(async()=>{
      const game=window.__game, s=game.scene.getScene("Level1Parte2"), c=s.cameras.main;
      const texture=s.textures.get("level1-parte2-escuridao");
      const {installPerformanceProbe}=await import("/debug/PerformanceProbe.js");
      const probe=installPerformanceProbe(game,{observeLongTasks:false});probe.watchScene(s);
      c.stopFollow();s.player.setVelocity(0,0);
      for(const z of s.zonasLuzApagada.zonas){z.liberada=z.restaurada=true;z.opacidade=0;}
      const reset=()=>{for(const key of Object.keys(s.__scrollStats))s.__scrollStats[key]=0;probe.reset();};
      const pose=(name,i)=>{
        s.time.now=name==="dynamic"?1000+i*1000/30:1000;
        s.player.setVisible(name==="dynamic");s.companionPet?.setVisible(name==="dynamic");
        if(name==="dynamic")s.player.setPosition(-1100+i*2,-4800).setFrame(i%4);
        let x=-1100,y=-4800;
        if(name==="integer-x"||name==="dynamic")x+=i*2;
        if(name==="fractional")x+=i*.7;
        if(name==="integer-y")y+=i*2;
        if(name==="reverse")x+=(i<10?i:20-i)*2;
        const shake=name==="shake-zoom";
        if(shake){x+=Math.sin(i)*4+.25;y+=Math.cos(i)*3;}
        c.setZoom(shake?1+(i%3)*.015:1).setRotation(shake?(i%2)*.025:0).centerOn(x,y);
      };
      const batches=[];
      try {
        // Primeiro mede sem readbacks de pixels entre quadros.
        for(let batch=0;batch<4;batch++) {
          const optimized=batch%2===1;s.__scrollEnabled=optimized;s.definirIluminacaoFabrica(true);
          for(let i=0;i<10;i++){pose("integer-x",i);game.step(1000+i*1000/30,1000/30);}
          reset();
          const times=[];
          for(let i=10;i<50;i++){
            pose("integer-x",i);const start=performance.now();game.step(1000+i*1000/30,1000/30);times.push(performance.now()-start);
          }
          times.sort((a,b)=>a-b);
          const {metrics,counters}=probe.snapshot();
          batches.push({optimized,frames:40,mean:times.reduce((a,b)=>a+b,0)/40,median:times[19],p95:times[37],p99:times[39],max:times[39],
            overBudget:times.filter(t=>t>1000/30).length,metrics,counters,scroll:{...s.__scrollStats}});
        }
        const comparisons=[];
        // Comparações byte a byte, separadas da medição de desempenho.
        for(const name of ["integer-x","fractional","integer-y","reverse","shake-zoom","dynamic"]){
          const reference=[];let channels=0,maxDifference=0;
          const stats=[];
          for(const enabled of [false,true]){
            s.__scrollEnabled=enabled;s.definirIluminacaoFabrica(name!=="dynamic");reset();
            for(let i=0;i<20;i++){
              pose(name,i);game.step(1000+i*1000/30,1000/30);
              const pixels=texture.context.getImageData(0,0,texture.width,texture.height).data;
              if(!enabled)reference.push(pixels);
              else for(let j=0;j<pixels.length;j++)if(pixels[j]!==reference[i][j]){
                channels++;maxDifference=Math.max(maxDifference,Math.abs(pixels[j]-reference[i][j]));
              }
            }
            stats.push({...s.__scrollStats});
          }
          comparisons.push({name,frames:20,channels,maxDifference,stats});
        }
        const gl=game.renderer.gl,ext=gl.getExtension("WEBGL_debug_renderer_info");
        return {canvas:{width:game.canvas.width,height:game.canvas.height},mask:{width:texture.width,height:texture.height},
          heap:performance.memory?.usedJSHeapSize,adapter:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),
          gpuTimerAvailable:!!gl.getExtension("EXT_disjoint_timer_query_webgl2"),
          extraCanvasBytes:texture.width*texture.height*4,batches,comparisons};
      } finally {s.__scrollEnabled=false;probe.stop();}
    });
    reports.push(report);
    writeFileSync("/tmp/nullborns-stage4-scroll.json",JSON.stringify({reports,errors:session.errors},null,2));
    console.log(JSON.stringify(report));
  }
  assert.deepEqual(session.errors,[]);
} finally {await session.fechar();}
