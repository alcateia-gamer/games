/** Compara cache espacial com a composição atual, antes de considerar sua integração. */
import assert from "node:assert/strict";
import {writeFileSync} from "node:fs";
import {abrirSessaoNovoBoss} from "./novo-boss-browser-helpers.mjs";
import {novoBossConfig} from "../js/enemies/novoBoss/NovoBossConfig.js";
const session=await abrirSessaoNovoBoss(novoBossConfig,{spawnX:-1100,spawnY:-4800},{viewport:{width:960,height:540},hasTouch:true,isMobile:true,
  userAgent:"Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36"},{waitForBoss:false});
try{
  const result=await session.page.evaluate(async()=>{
    const {default:Class}=await import("/js/effects/FixedLightCache.js");
    const {fixedWorldPatchExperiment}=await import("/debug/FixedWorldPatchExperiment.js");
    const experiment=fixedWorldPatchExperiment(Class),game=window.__game,s=game.scene.getScene("Level1Parte2"),c=s.cameras.main;
    const t=s.textures.get("level1-parte2-escuridao");
    s.player.setVisible(false);s.companionPet?.setVisible(false);s.definirIluminacaoFabrica(true);c.stopFollow().setZoom(1.8);
    for(const z of s.zonasLuzApagada.zonas){z.liberada=z.restaurada=true;z.opacidade=0;}
    const reference=[];let channels=0,maxDifference=0;
    const batches=[];
    try{
      for(const enabled of [false,true]){
        experiment.enable(enabled);s.definirIluminacaoFabrica(true);
        for(let i=0;i<16;i++){
          s.time.now=1000;c.centerOn(-1280+i*.7,-4864);
          game.step(1000+i*1000/30,1000/30);
          const data=t.context.getImageData(0,0,t.width,t.height).data;
          if(!enabled)reference.push(data);
          else for(let j=0;j<data.length;j++)if(data[j]!==reference[i][j]){channels++;maxDifference=Math.max(maxDifference,Math.abs(data[j]-reference[i][j]));}
        }
        batches.push({enabled,stats:{...experiment.stats}});
      }
      return {frames:16,channels,maxDifference,batches,heap:performance.memory?.usedJSHeapSize};
    }finally{experiment.restore();}
  });
  writeFileSync("/tmp/nullborns-stage4-world-patch.json",JSON.stringify({result,errors:session.errors},null,2));console.log(JSON.stringify(result));
  assert.deepEqual(session.errors,[]);
}finally{await session.fechar();}
